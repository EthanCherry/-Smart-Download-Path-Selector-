// 监听下载开始事件
chrome.downloads.onDeterminingFilename.addListener((downloadItem, suggest) => {
  // 暂停下载，等待用户选择路径
  chrome.downloads.pause(downloadItem.id);
  
  // 获取保存的路径设置
  chrome.storage.sync.get(['favoritePaths', 'recentPaths'], (result) => {
    const favoritePaths = result.favoritePaths || [];
    const recentPaths = result.recentPaths || [];
    
    // 打开路径选择对话框
    chrome.windows.create({
      url: `pathSelector.html?downloadId=${downloadItem.id}&filename=${encodeURIComponent(downloadItem.filename)}`,
      type: 'popup',
      width: 600,
      height: 400,
      left: 100,
      top: 100
    });
  });
  
  // 暂时不建议文件名，等待用户选择路径后再处理
  return { cancel: true };
});

// 处理用户选择的路径
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'confirmDownloadPath') {
    const { downloadId, path, filename } = message;
    
    // 恢复并修改下载路径
    chrome.downloads.search({ id: downloadId }, (items) => {
      if (items.length > 0) {
        const fullPath = path.endsWith('/') || path.endsWith('\\') 
          ? `${path}${filename}` 
          : `${path}/${filename}`;
        
        // 重新启动下载
        chrome.downloads.resume(downloadId, () => {
          chrome.downloads.setDestinationItem(downloadId, fullPath, () => {
            sendResponse({ success: true });
          });
        });
      }
    });
    
    // 保存到最近使用的路径
    if (path) {
      chrome.storage.sync.get('recentPaths', (result) => {
        let recentPaths = result.recentPaths || [];
        // 去重并保持最新的5条记录
        recentPaths = [path, ...recentPaths.filter(p => p !== path)].slice(0, 5);
        chrome.storage.sync.set({ recentPaths });
      });
    }
    
    return true; // 表示会异步发送响应
  }
});
    