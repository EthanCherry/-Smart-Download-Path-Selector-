// 加载常用路径列表
function loadPaths() {
  chrome.storage.sync.get('favoritePaths', (result) => {
    const favoritePaths = result.favoritePaths || [];
    const pathList = document.getElementById('pathList');
    pathList.innerHTML = '';
    
    if (favoritePaths.length === 0) {
      pathList.innerHTML = '<div class="path-item">暂无常用路径，请添加</div>';
      return;
    }
    
    favoritePaths.forEach((path, index) => {
      const pathItem = document.createElement('div');
      pathItem.className = 'path-item';
      
      pathItem.innerHTML = `
        <span class="path-text">${path}</span>
        <button class="delete-btn" data-index="${index}">删除</button>
      `;
      
      pathList.appendChild(pathItem);
    });
    
    // 添加删除事件监听
    document.querySelectorAll('.delete-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const index = parseInt(e.target.getAttribute('data-index'));
        deletePath(index);
      });
    });
  });
}

// 添加新路径
function addPath() {
  const newPathInput = document.getElementById('newPath');
  const path = newPathInput.value.trim();
  
  if (!path) {
    showMessage('请输入路径', 'error');
    return;
  }
  
  chrome.storage.sync.get('favoritePaths', (result) => {
    let favoritePaths = result.favoritePaths || [];
    
    // 检查路径是否已存在
    if (favoritePaths.includes(path)) {
      showMessage('该路径已存在', 'error');
      return;
    }
    
    // 添加新路径
    favoritePaths.push(path);
    chrome.storage.sync.set({ favoritePaths }, () => {
      loadPaths();
      newPathInput.value = '';
      showMessage('路径添加成功', 'success');
    });
  });
}

// 删除路径
function deletePath(index) {
  chrome.storage.sync.get('favoritePaths', (result) => {
    let favoritePaths = result.favoritePaths || [];
    favoritePaths.splice(index, 1);
    chrome.storage.sync.set({ favoritePaths }, () => {
      loadPaths();
      showMessage('路径已删除', 'success');
    });
  });
}

// 显示消息
function showMessage(text, type) {
  const messageEl = document.getElementById('statusMessage');
  messageEl.textContent = text;
  messageEl.className = 'status-message ' + type;
  
  // 3秒后隐藏消息
  setTimeout(() => {
    messageEl.className = 'status-message';
  }, 3000);
}

// 初始化
document.addEventListener('DOMContentLoaded', () => {
  loadPaths();
  
  // 添加路径按钮事件
  document.getElementById('addPathBtn').addEventListener('click', addPath);
  
  // 回车添加路径
  document.getElementById('newPath').addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      addPath();
    }
  });
});
    