// 打开设置页面
document.getElementById('optionsBtn').addEventListener('click', () => {
  chrome.runtime.openOptionsPage();
  window.close();
});

// 清除最近路径
document.getElementById('clearRecentBtn').addEventListener('click', () => {
  if (confirm('确定要清除所有最近使用的路径吗？')) {
    chrome.storage.sync.set({ recentPaths: [] }, () => {
      alert('已清除最近使用的路径');
      window.close();
    });
  }
});
    