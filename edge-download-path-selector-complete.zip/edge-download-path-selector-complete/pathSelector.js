// 解析URL参数
function getUrlParams() {
  const params = new URLSearchParams(window.location.search);
  return {
    downloadId: parseInt(params.get('downloadId')),
    filename: decodeURIComponent(params.get('filename'))
  };
}

// 获取参数
const { downloadId, filename } = getUrlParams();

// 显示文件名
document.getElementById('filename').textContent = filename;

// 选中的路径
let selectedPath = '';

// 加载路径列表
function loadPaths() {
  chrome.storage.sync.get(['favoritePaths', 'recentPaths'], (result) => {
    const favoritePaths = result.favoritePaths || [];
    const recentPaths = result.recentPaths || [];
    
    // 显示最近使用的路径
    const recentPathsEl = document.getElementById('recentPaths');
    recentPathsEl.innerHTML = recentPaths.length > 0 
      ? '' 
      : '<div>暂无最近使用的路径</div>';
    
    recentPaths.forEach(path => {
      const btn = document.createElement('button');
      btn.className = 'path-btn';
      btn.textContent = path;
      btn.addEventListener('click', () => selectPath(path));
      recentPathsEl.appendChild(btn);
    });
    
    // 显示常用路径
    const favoritePathsEl = document.getElementById('favoritePaths');
    favoritePathsEl.innerHTML = favoritePaths.length > 0 
      ? '' 
      : '<div>暂无常用路径，请在设置中添加</div>';
    
    favoritePaths.forEach(path => {
      const btn = document.createElement('button');
      btn.className = 'path-btn';
      btn.textContent = path;
      btn.addEventListener('click', () => selectPath(path));
      favoritePathsEl.appendChild(btn);
    });
  });
}

// 选择路径
function selectPath(path) {
  selectedPath = path;
  
  // 更新UI显示选中状态
  document.querySelectorAll('.path-btn').forEach(btn => {
    if (btn.textContent === path) {
      btn.classList.add('selected');
    } else {
      btn.classList.remove('selected');
    }
  });
  
  // 更新输入框
  document.getElementById('customPath').value = path;
}

// 确认下载
function confirmDownload() {
  // 检查是否有选中的路径或自定义路径
  const customPath = document.getElementById('customPath').value.trim();
  const pathToUse = customPath || selectedPath;
  
  if (!pathToUse) {
    alert('请选择或输入下载路径');
    return;
  }
  
  // 发送消息给后台，确认下载路径
  chrome.runtime.sendMessage({
    action: 'confirmDownloadPath',
    downloadId,
    path: pathToUse,
    filename
  }, (response) => {
    if (response && response.success) {
      window.close(); // 关闭对话框
    } else {
      alert('设置下载路径失败，请重试');
    }
  });
}

// 取消下载
function cancelDownload() {
  // 取消下载
  chrome.downloads.cancel(downloadId, () => {
    window.close(); // 关闭对话框
  });
}

// 初始化
document.addEventListener('DOMContentLoaded', () => {
  loadPaths();
  
  // 确认按钮事件
  document.getElementById('confirmBtn').addEventListener('click', confirmDownload);
  
  // 取消按钮事件
  document.getElementById('cancelBtn').addEventListener('click', cancelDownload);
  
  // 自定义路径输入事件
  document.getElementById('customPath').addEventListener('input', (e) => {
    selectedPath = e.target.value.trim();
    // 移除所有选中状态
    document.querySelectorAll('.path-btn').forEach(btn => {
      btn.classList.remove('selected');
    });
  });
  
  // 回车确认
  document.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      confirmDownload();
    }
  });
});
    