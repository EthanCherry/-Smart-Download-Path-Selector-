// 监听页面中的下载链接点击
document.addEventListener('click', (e) => {
  // 检查点击的是否是下载链接
  let link = e.target.closest('a[href]');
  
  if (link) {
    const href = link.getAttribute('href');
    // 常见的下载文件扩展名
    const fileExtensions = /\.(zip|rar|7z|tar|gz|pdf|doc|docx|xls|xlsx|ppt|pptx|jpg|jpeg|png|gif|mp3|mp4|exe|dmg|pkg)$/i;
    
    // 判断链接是否指向可能的下载文件
    if (fileExtensions.test(href) || 
        href.includes('download') || 
        link.textContent.toLowerCase().includes('download')) {
      console.log('检测到可能的下载链接:', href);
      // 可以在这里添加一些预处理逻辑
    }
  }
}, true);
    